package wargame;

import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;


public class Mouse extends JPanel implements MouseListener , MouseMotionListener {


    public int firstX;
    public int firstY;
    public int secondX;
    public int secondY;

    public Mouse() {
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        int x=e.getX();
        int y=e.getY();
        System.out.println("Clicked!"+x+","+y);
    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        int x=e.getX();
        int y=e.getY();
        System.out.println(x+","+y);
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        System.out.println("yooo");
    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }
}



