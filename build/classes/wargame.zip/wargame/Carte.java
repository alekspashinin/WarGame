package wargame;

import java.awt.Graphics;
import java.util.*;

import wargame.ISoldat.TypesH;

public class Carte implements ICarte, IConfig {

	public Element[][] carte;

	public Carte() {
		carte = new Element[LARGEUR_CARTE][HAUTEUR_CARTE];
		// carte = new Element[HAUTEUR_CARTE][LARGEUR_CARTE];

		for (int i = 0; i < LARGEUR_CARTE; i++) {
			for (int j = 0; j < HAUTEUR_CARTE; j++) {
				carte[i][j] = new Element();
				// ^ remplissage avec des elements vides
				// System.out.println(i+" "+j);

			}
		}
		TypesH genreHeros = TypesH.ELF;
		// carte[4][4] = new Heros(genreHeros,15,15);

	}

	@Override
	public Element getElement(Position pos) {
		return this.carte[pos.getX()][pos.getY()];
	}

	@Override

	public Position trouvePositionVide() {
		// Creation d'une liste qui va contenir tout les positions vides de la carte
		List<Position> pos = new ArrayList<Position>();
		for (int i = 0; i < LARGEUR_CARTE; i++) {
			for (int j = 0; j < HAUTEUR_CARTE; j++) {
				// Ajout de tous les Heros dans cette liste
				if (!this.carte[i][j].ElemEstOccupe())
					pos.add(new Position(i, j));
			}
		}
		// Si la liste est vide (s'il existe donc pas de positions vides retour null)
		// Verification devra etre faite lors de l'appel de la fonction affin de
		// verifier le retour null
		if (pos.isEmpty())
			return null;
		else {
			// Sinon choix alleatoir parmis les positions vides trouves
			int choix = new Random().nextInt(pos.size());
			return pos.get(choix);
		}

	}

	/*
	 * public Position trouvePositionVide() {
	 * 
	 * int i, j, end = 1; i = (int) (Math.random() * HAUTEUR_CARTE);
	 * System.out.println("hauteur:" + i); j = (int) (Math.random() *
	 * LARGEUR_CARTE); System.out.println("largeur:" + j); Position pos = new
	 * Position(j, i); while (i < HAUTEUR_CARTE && end == 1) { //
	 * System.out.println("yyy"); do { if (!this.carte[j][i].ElemEstOccupe()) { pos
	 * = new Position(j, i); end = 0; } j++; } while (j < LARGEUR_CARTE && end ==
	 * 1); j = 0; i++; } if (this.carte[pos.getX()][pos.getY()].ElemEstOccupe()) {
	 * trouvePositionVide(); } return pos;
	 * 
	 * }
	 */

	@Override
	public Position trouvePositionVide(Position pos) {
		// Creation d'une liste qui va contenir tout les positions vides de la carte
		List<Position> posi = new ArrayList<Position>();
		for (int i = (pos.getX() - 1); i < LARGEUR_CARTE && i <= (pos.getX() + 1); i++) {
			for (int j = (pos.getY() - 1); j < HAUTEUR_CARTE && j <= (pos.getY() + 1); j++) {
				// Ajout de tous les Heros dans cette liste
				if (!this.carte[i][j].ElemEstOccupe())
					posi.add(new Position(i, j));
			}
		}
		// Si la liste est vide (s'il existe donc pas de positions vides retour null)
		// Verification devra etre faite lors de l'appel de la fonction affin de
		// verifier le retour null
		if (posi.isEmpty())
			return null;
		else {
			// Sinon choix alleatoir parmis les positions vides trouves
			int choix = new Random().nextInt(posi.size());
			return posi.get(choix);
		}

	}

	/*
	 * public Position trouvePositionVide(Position pos) { // ne pas oublier
	 * verification de l'existance d'une position vide dans // l'intervale int i, j,
	 * end = 1; i = (int) (Math.random() * ((pos.getY() + 1) - (pos.getY() - 1)) +
	 * (pos.getY() - 1)); // HAUTEUR_CARTE j = (int) (Math.random() * ((pos.getX() +
	 * 1) - (pos.getX() - 1)) + (pos.getX() - 1)); // LARGEUR_CARTE
	 * System.out.println("larg" + j); System.out.println("haut" + i); Position
	 * newPos = new Position(j, i); while (i < HAUTEUR_CARTE && i <= pos.getY() + 1
	 * && end == 1) { do { if (!this.carte[j][i].ElemEstOccupe()) { newPos = new
	 * Position(j, i); end = 0; } j++; } while (j < LARGEUR_CARTE && j <= pos.getX()
	 * + 1 && end == 1); j = pos.getX() - 1; i++; } if
	 * (this.carte[newPos.getX()][newPos.getY()].ElemEstOccupe()) {
	 * trouvePositionVide(pos); // System.out.println("rec call"); } return newPos;
	 * 
	 * }
	 */

	@Override
	/*
	 * public Heros trouveHeros() {
	 * 
	 * int i, j, end = 1; i = (int) (Math.random() * HAUTEUR_CARTE); j = (int)
	 * (Math.random() * LARGEUR_CARTE); Element hero = new Element(); // Heros hero
	 * = new Heros(TypesH.ELF, new Position(5, 7)); while (i < HAUTEUR_CARTE && end
	 * == 1) { do { if (this.carte[j][i] instanceof Heros) {
	 * //System.out.println("found one"); hero = this.carte[j][i]; end = 0; } j++; }
	 * while (j < LARGEUR_CARTE && end == 1); j = 0; i++; } if (hero instanceof
	 * Heros == false) { // System.out.println("rec call"); return trouveHeros();
	 * 
	 * } return (Heros) hero; }
	 */

	public Heros trouveHeros() {
		// Creation d'une liste qui va contenir tout les heros de la carte
		List<Heros> hero = new ArrayList<Heros>();
		for (int i = 0; i < LARGEUR_CARTE; i++) {
			for (int j = 0; j < HAUTEUR_CARTE; j++) {
				// Ajout de tous les Heros dans cette liste
				if (this.carte[i][j] instanceof Heros)
					hero.add((Heros) this.carte[i][j]);
			}
		}
		// Si la liste est vide (s'il existe donc pas de heros retour null)
		// Verification devra etre faite lors de l'appel de la fonction affin de
		// verifier le retour null
		if (hero.isEmpty())
			return null;
		else {
			// Sinon choix alleatoir parmis les heros trouves
			int choix = new Random().nextInt(hero.size());
			return hero.get(choix);
		}

	}

	@Override

	public Heros trouveHeros(Position pos) {
		// Creation d'une liste qui va contenir tout les heros de la carte dans
		// l'interval demande
		List<Heros> hero = new ArrayList<Heros>();
		for (int i = (pos.getX() - 1); i < LARGEUR_CARTE && i <= (pos.getX() + 1); i++) {
			for (int j = (pos.getY() - 1); j < HAUTEUR_CARTE && j <= (pos.getY() + 1); j++) {
				// Ajout de tous les Heros dans cette liste
				if (this.carte[i][j] instanceof Heros)
					hero.add((Heros) this.carte[i][j]);
			}
		}
		// Si la liste est vide (s'il existe donc pas de heros retour null)
		// Verification devra etre faite lors de l'appel de la fonction affin de
		// verifier le retour null
		if (hero.isEmpty())
			return null;
		else {
			// Sinon choix alleatoir parmis les heros trouves
			int choix = new Random().nextInt(hero.size());
			return hero.get(choix);
		}
	}
	/*
	 * public Heros trouveHeros(Position pos) { // ne pas oublier verification de
	 * l'existance d'un hero dans l'intervale int i, j, end = 1; i = (int)
	 * (Math.random() * ((pos.getY() + 1) - (pos.getY() - 1)) + (pos.getY() - 1));
	 * // HAUTEUR_CARTE j = (int) (Math.random() * ((pos.getX() + 1) - (pos.getX() -
	 * 1)) + (pos.getX() - 1)); // LARGEUR_CARTE //
	 * System.out.println("haut:"+i+" larg:"+j); Element hero = new Element(); while
	 * (i < HAUTEUR_CARTE && i <= pos.getY() + 1 && end == 1) { do { //
	 * System.out.println("looking"+j+" "+i); if (this.carte[j][i] instanceof Heros)
	 * { // System.out.println("found one"); hero = this.carte[j][i]; end = 0; }
	 * j++; } while (j < LARGEUR_CARTE && j <= pos.getX() + 1 && end == 1); j =
	 * pos.getX() - 1; i++; }
	 * 
	 * if (hero instanceof Heros == false) { return trouveHeros(pos); }
	 * 
	 * return (Heros) hero;
	 * 
	 * }
	 */

	@Override
	public void ajouterElement(Position pos,Element elem) {
		carte[pos.getX()][pos.getY()]=elem;
		carte[pos.getX()][pos.getY()].setPosition(pos);		
	}
	
	@Override
	public boolean deplaceSoldat(Position pos, Soldat soldat) {
		if (!this.carte[pos.getX()][pos.getY()].ElemEstOccupe()) {
			soldat.seDeplace(pos);
			this.carte[pos.getX()][pos.getY()] = soldat;
			return true;

		}
		return false;
	}

	@Override
	public void mort(Soldat perso) {
		// perso.setPoints(0);
		Position pos = perso.getPosition();
		this.carte[pos.getX()][pos.getY()] = new Element();
	}

	@Override
	public boolean actionHeros(Position pos, Position pos2) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void jouerSoldats(PanneauJeu pj) {
		// TODO Auto-generated method stub

	}

	@Override
	public void toutDessiner(Graphics g) {
		// TODO Auto-generated method stub

	}

}
