package wargame;

public class Soldat extends Element implements ISoldat {

	public int points;
	public int portee;
	public int puissance;
	public int tir;


	public Soldat(Position pos,int points, int portee, int puissance, int tir) {
		super(pos);
		this.points = points;
		this.portee = portee;
		this.puissance = puissance;
		this.tir = tir;
		
	}
	
	public Soldat(int xPos, int yPos,int points, int portee, int puissance, int tir) {
		super(xPos,yPos);
		this.points = points;
		this.portee = portee;
		this.puissance = puissance;
		this.tir = tir;
		
	}

	public boolean estVivantSoldat() {
		return this.points != 0;
		// ^ true si le soldat est vivant false sinon
	}

	//Accesseurs
	
	@Override
	public int getPoints() {
		return points;

	}

	@Override
	public int getTour() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getPortee() {
		return portee;
	}

	public int getPuissance() {
		return puissance;
	}

	public int getTir() {
		return tir;
	}
	
	
	//Mutateurs
	
	public void setPoints(int points) {
		this.points = points;
	}
	

	@Override
	public void joueTour(int tour) {
		// TODO Auto-generated method stub

	}

	@Override
	public void combat(Soldat soldat) {
		// TODO Auto-generated method stub

	}

	@Override
	public void seDeplace(Position newPos) {
		setPosition(newPos);
		

	}

}
