package wargame;



public class Heros extends Soldat{

	
	public Heros(TypesH genreHeros,Position pos) {
		super(pos,genreHeros.getPoints(), genreHeros.getPortee(), genreHeros.getPuissance(), genreHeros.getTir());
	}
	
	public Heros(TypesH genreHeros,int posX,int posY) {
		super(posX,posY,genreHeros.getPoints(), genreHeros.getPortee(), genreHeros.getPuissance(), genreHeros.getTir());
	}
	
	
	public boolean estVivantHeros() {
		return super.estVivantSoldat();
	}
	
	//Accesseurs
	
	public int getPointsHeros() {
		return super.getPoints();
	}
	
	public int getPorteeHeros() {
		 return super.getPortee();
	}
	
	public int getPuissanceHeros() {
		return super.getPortee();
	}
	
	public int getTirHeros() {
		return super.getTir();
	}
	
	//getTour
	
	//Mutateurs
	
	public void setPointsHeros(int points) {
		super.setPoints(points);
	}
	

}
