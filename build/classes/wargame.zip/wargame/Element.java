package wargame;

public class Element {
	
	private int estOccupe;
	private Position pos;
	
	// sert a construire un element "vide" puisque null existe pas en java 
	//on va suposer null les positions non occupes
	public Element() {
		this.estOccupe=0;
	}
	
	public Element(int x, int y) {
		this.estOccupe=1;
		this.pos=new Position(x, y);
	}
	
	
	
	public Element(Position pos) {
		this.estOccupe=1;
		this.pos=new Position(pos.getX(), pos.getY());

	}

	
	//accesseurs
	public boolean ElemEstOccupe() {
		return (this.estOccupe!=0); 
		// ^ true si l'element est occupe et false s'il est libre
	}
	
	public Position getPosition() {
		return this.pos;		
	}
	
	
	//mutateurs
	
	public void setEstOccupe(int i) {
		this.estOccupe=i;
	}
	
	public void setPosition(Position p) {
		this.pos.setX(p.getX());
		this.pos.setY(p.getY());
	}
	
	
	
	
	
	
		

}
