package wargame;

import wargame.ISoldat.TypesH;

public class test {
	// Main TEMPORAIRE
	public static void main(String []args) {
		

		Carte c=new Carte();
		//c.affichageCarte();
		//c.carte[23][13]=new Heros(TypesH.ELF, new Position(23, 13));
		//System.out.println(c.carte[23][13].getPosition().getX());
		//c.carte[23][12]=new Heros(TypesH.ELF, new Position(23, 12));
		//c.carte[24][13]=new Heros(TypesH.ELF, new Position(24, 13));
		c.carte[6][8]=new Heros(TypesH.ELF, new Position(6, 8));
		Heros hero=new Heros(TypesH.HOBBIT, new Position(5, 7)) ;
		c.ajouterElement(new Position(7,8), new Heros(TypesH.ELF, new Position(1, 1)));
		hero=c.trouveHeros(new Position(14, 14));
		if(hero==null) {
			System.out.println("no heros");
		}
		else {
			Position pos =hero.getPosition();
			System.out.println(pos.getX());
		}
		
		//System.out.println(c.carte[23][13].ElemEstOccupe());
		//Position p=c.trouvePositionVide();
		//Position p=c.trouvePositionVide(new Position(24, 13));
		
	}

}
