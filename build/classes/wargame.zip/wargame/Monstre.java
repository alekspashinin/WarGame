package wargame;


public class Monstre extends Soldat{
	
	public Monstre(TypesM genreMonstre,Position pos) {
		super(pos,genreMonstre.getPoints(), genreMonstre.getPortee(), genreMonstre.getPuissance(), genreMonstre.getTir());
	}
	
	public Monstre(TypesM genreMonstre,int posX, int posY) {
		super(posX,posY,genreMonstre.getPoints(), genreMonstre.getPortee(), genreMonstre.getPuissance(), genreMonstre.getTir());
	}
	
	public boolean estVivantMonstre() {
		return super.estVivantSoldat();
	}
	
	//Accesseurs
	
	public int getPointsMonstre() {
		return super.getPoints();
	}
	
	public int getPorteeMonstre() {
		 return super.getPortee();
	}
	
	public int getPuissanceMonstre() {
		return super.getPortee();
	}
	
	public int getTirMonstre() {
		return super.getTir();
	}
	
	//getTour
	
	//Mutateurs
	
	public void setPointsMonstre(int points) {
		super.setPoints(points);
	}
	

}
