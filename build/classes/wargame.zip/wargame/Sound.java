/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wargame;

import java.io.*;
import javax.sound.sampled.*;
import javax.swing.*;
/**
 *
 * @author alekspashinin
 */
public class Sound extends JFrame{
    
   public Sound() {   
      try {          
          File soundFile = new File("/Users/alekspashinin/NetBeansProjects/WarGame/src/wargame/Music/click.wav"); //you could also get the sound file with an URL
          AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFile);              
         Clip clip = AudioSystem.getClip();
         clip.open(audioIn);
         clip.start();
      } 
      catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
      }
   }
}
